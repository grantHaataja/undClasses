//Grant Haataja
//Assignment 6: SCAN Header

#include <stdio.h>
#include <stdlib.h>

//function to open the file/stream and count how many lines it contains
int SCAN(char *fileName, FILE *(*stream));
