//Grant Haataja
//Assignment 6: Structure Header

#include <stdio.h>
#include <stdlib.h>

//Structure
struct _data {                                 
	char *name;
	long number;
};
