//Grant Haataja
//Assignment 6: SEARCH Header

#include <stdio.h>
#include <stdlib.h>

//function to find the name we are searching for 
void SEARCH(struct _data *BlackBox, char *name, int size);
