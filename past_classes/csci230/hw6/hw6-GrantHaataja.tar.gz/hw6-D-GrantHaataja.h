//Grant Haataja
//Assignment 6: FREE Header

#include <stdio.h>
#include <stdlib.h>

//function to free all dynamic memory allocated in this program
void FREE(struct _data *BlackBox, int size, char *fileName);
